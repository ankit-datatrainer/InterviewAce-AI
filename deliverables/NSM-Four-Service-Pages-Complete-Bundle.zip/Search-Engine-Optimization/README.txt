NSM MARKETING — SEARCH ENGINE OPTIMIZATION

FILES
- NSM-Search-Engine-Optimization-Elementor-Template.json — import this file into Elementor
- preview.html — responsive visual preview
- images/nsm-seo-hero.webp
- images/nsm-seo-strategy-workshop.webp

IMPORT
1. WordPress → Templates → Saved Templates → Import Templates.
2. Import NSM-Search-Engine-Optimization-Elementor-Template.json; do not import a ZIP file as an Elementor template.
3. Insert the imported template into https://nsmmarketing.com/search-engine-optimization/
4. Upload both WebP files from the images folder to WordPress Media Library.
5. Replace the prepared hero and supporting image widgets with the supplied WebP files.
6. Add these Media Library alt texts:
   Hero: SEO strategist reviewing site architecture, search visibility, and content performance
   Supporting: SEO and content team mapping website architecture and search intent
7. Review contact and telephone links, then publish.

NOTES
- Uses core Elementor sections, columns, and widgets.
- No custom CSS, custom JavaScript, or third-party add-ons.
- Native entrance motion is disabled on mobile.
- The JSON uses existing public NSM images as temporary fallbacks so imported image widgets are not blank.
