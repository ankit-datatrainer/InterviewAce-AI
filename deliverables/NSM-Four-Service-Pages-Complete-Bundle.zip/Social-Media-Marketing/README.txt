NSM MARKETING — SOCIAL MEDIA MARKETING

FILES
- NSM-Social-Media-Marketing-Elementor-Template.json — import this file into Elementor
- preview.html — responsive visual preview
- images/nsm-social-media-marketing-hero.webp
- images/nsm-social-content-production.webp

IMPORT
1. WordPress → Templates → Saved Templates → Import Templates.
2. Import NSM-Social-Media-Marketing-Elementor-Template.json; do not import a ZIP file as an Elementor template.
3. Insert the imported template into https://nsmmarketing.com/social-media-marketing/
4. Upload both WebP files from the images folder to WordPress Media Library.
5. Replace the prepared hero and supporting image widgets with the supplied WebP files.
6. Add these Media Library alt texts:
   Hero: Social media campaign lead reviewing creative, content planning, and audience engagement
   Supporting: Social content team producing and reviewing a short-form campaign
7. Review contact and telephone links, then publish.

NOTES
- Uses core Elementor sections, columns, and widgets.
- No custom CSS, custom JavaScript, or third-party add-ons.
- Native entrance motion is disabled on mobile.
- The JSON uses existing public NSM images as temporary fallbacks so imported image widgets are not blank.
