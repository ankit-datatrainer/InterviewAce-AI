NSM MARKETING — PPC MANAGEMENT

FILES
- NSM-PPC-Elementor-Template.json — import this file into Elementor
- preview.html — responsive visual preview
- images/nsm-ppc-hero.webp
- images/nsm-ppc-optimization-workshop.webp

IMPORT
1. WordPress → Templates → Saved Templates → Import Templates.
2. Import NSM-PPC-Elementor-Template.json; do not import a ZIP file as an Elementor template.
3. Insert the imported template into https://nsmmarketing.com/ppc/
4. Upload both WebP files from the images folder to WordPress Media Library.
5. Replace the prepared hero and supporting image widgets with the supplied WebP files.
6. Add these Media Library alt texts:
   Hero: Paid media strategist reviewing campaign structure and conversion performance
   Supporting: Paid media team reviewing campaign creative and landing-page conversion paths
7. Review contact and telephone links, then publish.

NOTES
- Uses core Elementor sections, columns, and widgets.
- No custom CSS, custom JavaScript, or third-party add-ons.
- Native entrance motion is disabled on mobile.
- The JSON uses existing public NSM images as temporary fallbacks so imported image widgets are not blank.
